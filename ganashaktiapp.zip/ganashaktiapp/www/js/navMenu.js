// JavaScript Document
var navHtml = ' <nav>\
              <div class="close-sb"><a href="#" > X</a></div>\
                <ul>\
                <li><a href="#">রাজ্য​</a></li>\
                <li><a href="#"> জাতীয়​</a></li>\
                <li><a href="#"> আন্তর্জাতিক​</a></li>\
                 <li><a href="#">কলকাতা​</a></li>\
                <li><a href="#"> জেলা</a></li>\
                <li><a href="#"> খেলা​</a></li>\
                <li><a href="#"> সম্পাদকীয়​</a></li>\
                 <li><a href="#">উত্তর সম্পাদকীয়​</a></li>\
                <li><a href="#"> বিশেষ বিভাগ</a></li>\
                <li><a href="#"> পুরোনো সংস্করণ</a></li>\
                <li><a href="#"> যোগাযোগ​</a></li>\
                 <li><a href="#">আপনিই সাংবাদিক</a></li>\
                </ul>\
            </nav>';

function loadNav(){
	$("#main-sidebar").text((navHtml));
}

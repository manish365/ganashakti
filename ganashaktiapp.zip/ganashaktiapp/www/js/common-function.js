// JavaScript Document
function decodeHtml(html) {
    var txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}

function  loadAzkerDin(val){
	$.getJSON(AppUrls.azkerDinUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);
		if(typeof(data.ajkerdin)!="undefined" && data.ajkerdin.length>0){
			imagePath=data.imagepath;
			data=data.ajkerdin;
			for(i=0;i<data.length;i++)
			{
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].image+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].id+",ajkerdin\">"+data[i].heading+"</a></p></div><div class=\"clear\"></div></div>";
			}
			$(".article-section").html(html);
		}
	});
}

function  loadJatio(){
	$.getJSON(AppUrls.jatioUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);
		$(".article-section").empty();
		if(typeof(data.jatio)!="undefined" && data.jatio.length>0){
			imagePath=data.imagepath;
			data=data.jatio;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].thumb_image+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].web_id+",jatio\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadKhela(){
	$.getJSON(AppUrls.sportsUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);

		$(".article-section").empty();
		if(typeof(data.sports)!="undefined" && data.sports.length>0){
			imagePath=data.imagepath;
			data=data.sports;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].thumb_image+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].web_id+",sports\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadZilla(){
	$.getJSON(AppUrls.zillaUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);

		$(".article-section").empty();
		if(typeof(data.zilla)!="undefined" && data.zilla.length>0){
			imagePath=data.imagepath;
			data=data.zilla;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].thumb_image+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].web_id+",zilla\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadRajja(){
	$.getJSON(AppUrls.rajjaUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);
		$(".article-section").empty();
		if(typeof(data.rajjay)!="undefined" && data.rajjay.length>0){
			imagePath=data.imagepath;
			data=data.rajjay;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].thumb_image+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].web_id+",rajjay\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadKolkata(){
	$.getJSON(AppUrls.kolkataUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);
		$(".article-section").empty();
		if(typeof(data.kolkata)!="undefined" && data.kolkata.length>0){
			imagePath=data.imagepath;
			data=data.kolkata;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].thumb_image+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].web_id+",kolkata\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadAntarjatik(){
	$.getJSON(AppUrls.interNationalUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);
		$(".article-section").empty();
		if(typeof(data.international)!="undefined" && data.international.length>0){
			imagePath=data.imagepath;
			data=data.international;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].thumb_image+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+decodeHtml(data[i].heading)+",international\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadBisesvibhag(){
	$.getJSON(AppUrls.BishesBivagUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);
		$(".article-section").empty();
		if(typeof(data.bishesbivag)!="undefined" && data.bishesbivag.length>0){
			imagePath=data.imagepath;
			data=data.bishesbivag;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].big_img+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+decodeHtml(data[i].heading)+",bishesbivag\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadRabiwarerpata(){
	$.getJSON(AppUrls.robibarerpataUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);

		$(".article-section").empty();
		if(typeof(data.robibarerpata)!="undefined" && data.robibarerpata.length>0){
			imagePath=data.imagepath;
			data=data.robibarerpata;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].big_img+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].decodeHtml(data[i].heading)+",robibarerpata\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadUtarkal(){
	$.getJSON(AppUrls.uttarKalUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);

		$(".article-section").empty();
		if(typeof(data.uttarkal)!="undefined" && data.uttarkal.length>0){
			imagePath=data.imagepath;
			data=data.uttarkal;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].big_img+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].decodeHtml(data[i].heading)+",uttarkal\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

function  loadSamasar(){
	$.getJSON(AppUrls.somossorUrl, function(data){
		var html="";
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);

		$(".article-section").empty();
		if(typeof(data.somossor)!="undefined" && data.somossor.length>0){
			imagePath=data.imagepath;
			data=data.somossor;
			for(i=0;i<data.length;i++)
			{
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\""+imagePath+""+data[i].big_img+"\" ></div><div class=\"news-des\"><p><a href=\"news-details.html?NewsID="+data[i].decodeHtml(data[i].heading)+",somossor\">"+decodeHtml(data[i].heading)+"</a></p></div><div class=\"clear\"></div></div>";
			}
			$(".article-section").html(html);
		}
	});
}

function  loadSomoy(){
	$.getJSON(AppUrls.somoyUrl, function(data){
		$(".article-section").empty();
		localStorage.setItem("detailsview",'');
		var dataToStore = JSON.stringify(data);
		localStorage.setItem("detailsview",dataToStore);

		var html="";
		if(typeof(data.somay)!="undefined" && data.somay.length>0){
			data=data.somay;
			for(i=0;i<data.length;i++){
				
				html+="<div class=\"news-row\"><div class=\"news-img\"><img src=\"http://ganashakti.com/bengali/current_affairs/no_image_app.png\" ></div><div class=\"news-des\"><p>"+data[i].heading+"</p></div><div class=\"clear\"></div></div>";
				
			}
			$(".article-section").html(html);
		}
	});
}

 function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&amp;");
    for (var i=0;i<vars.length;i++) {
      var pair = vars[i].split("=");
      if (pair[0] == variable) {
      return pair[1];
    }
  }
  //alert('Query Variable ' + variable + ' not found');
}

function loadNewsDetails(VAL)
{
	var arr = VAL.split(',');
	if(arr[1]=='rajjay')
	{
		$(".news_details_head").html('রাজ্য');
		var data = JSON.parse(localStorage.getItem('detailsview'));
		//$.getJSON(AppUrls.rajjaUrl, function(data){
		var html="";
		if(typeof(data.rajjay)!="undefined" && data.rajjay.length>0){
			imagePath=data.imagepath;
			data=data.rajjay;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].post_date+"</date><br>\
					<font color=\"red\">"+data[i].writer+"</font>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='ajkerdin')
	{
		$(".news_details_head").html('আজকের দিনে');
		//$.getJSON(AppUrls.azkerDinUrl, function(data){
		var data = JSON.parse(localStorage.getItem('detailsview'));
		var html="";
		if(typeof(data.ajkerdin)!="undefined" && data.ajkerdin.length>0){
			imagePath=data.imagepath;
			data=data.ajkerdin;
			for(i=0;i<data.length;i++)
			{
				if(data[i].id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+data[i].heading+"</h2>\
					<date>"+data[i].upload_timestamp+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
		//)};		
	}
	else if(arr[1]=='jatio')
	{
		$(".news_details_head").html('জাতীয়');
		var data = JSON.parse(localStorage.getItem('detailsview'));

		//$.getJSON(AppUrls.jatioUrl, function(data){
		var html="";
		if(typeof(data.jatio)!="undefined" && data.jatio.length>0){
			imagePath=data.imagepath;
			data=data.jatio;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='sports')
	{
		$(".news_details_head").html('খেলা​');
		var data = JSON.parse(localStorage.getItem('detailsview'));

		//$.getJSON(AppUrls.sportsUrl, function(data){
		var html="";
		if(typeof(data.sports)!="undefined" && data.sports.length>0){
			imagePath=data.imagepath;
			data=data.sports;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='zilla')
	{
		$(".news_details_head").html('জেলা');
		var data = JSON.parse(localStorage.getItem('detailsview'));

		//$.getJSON(AppUrls.zillaUrl, function(data){
		var html="";
		if(typeof(data.zilla)!="undefined" && data.zilla.length>0){
			imagePath=data.imagepath;
			data=data.zilla;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='kolkata')
	{
		$(".news_details_head").html('কলকাতা');
		var data = JSON.parse(localStorage.getItem('detailsview'));

		//$.getJSON(AppUrls.kolkataUrl, function(data){
		var html="";
		if(typeof(data.kolkata)!="undefined" && data.kolkata.length>0){
			imagePath=data.imagepath;
			data=data.kolkata;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='international')
	{
		$(".news_details_head").html('আন্তর্জাতিক');
		var data = JSON.parse(localStorage.getItem('detailsview'));

		//$.getJSON(AppUrls.interNationalUrl, function(data){
		var html="";
		if(typeof(data.international)!="undefined" && data.international.length>0){
			imagePath=data.imagepath;
			data=data.international;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='bishesbivag')
	{
		$(".news_details_head").html('বিশেষ বিভাগ');
		var data = JSON.parse(localStorage.getItem('detailsview'));

		//$.getJSON(AppUrls.BishesBivagUrl, function(data){
		var html="";
		if(typeof(data.bishesbivag)!="undefined" && data.bishesbivag.length>0){
			imagePath=data.imagepath;
			data=data.bishesbivag;
			for(i=0;i<data.length;i++)
			{
				alert(data[i].postdate);
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].big_img+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='robibarerpata')
	{
		$(".news_details_head").html('রবিবারের পাতা');
		var data = JSON.parse(localStorage.getItem('detailsview'));

		//$.getJSON(AppUrls.robibarerpataUrl, function(data){
		var html="";
		if(typeof(data.robibarerpata)!="undefined" && data.robibarerpata.length>0){
			imagePath=data.imagepath;
			data=data.robibarerpata;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});

	}
	else if(arr[1]=='uttarkal')
	{
		$(".news_details_head").html('উত্তরকাল');
		var data = JSON.parse(localStorage.getItem('detailsview'));
		//$.getJSON(AppUrls.uttarKalUrl, function(data){
		var html="";
		if(typeof(data.uttarkal)!="undefined" && data.uttarkal.length>0){
			imagePath=data.imagepath;
			data=data.uttarkal;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});
	}
	else if(arr[1]=='somossor')
	{
		$(".news_details_head").html('সমস্বর');
		var data = JSON.parse(localStorage.getItem('detailsview'));
		//$.getJSON(AppUrls.somossorUrl, function(data){
		var html="";
		if(typeof(data.somossor)!="undefined" && data.somossor.length>0){
			imagePath=data.imagepath;
			data=data.somossor;
			for(i=0;i<data.length;i++)
			{
				if(data[i].web_id==arr[0])
				{
					html+="<article>\
					<figure><img src=\""+imagePath+""+data[i].thumb_image+"\" ></figure>\
					<div class=\"newshead_date\">\
					<h2>"+decodeHtml(data[i].heading)+"</h2>\
					<date>"+data[i].postdate+"</date>\
					</div>\
					<div class=\"news_details\">"+data[i].description+"</div>\
					</article>";
				}
			}
					$("#detailsNews").html(html);
		}
	//});
	}

}
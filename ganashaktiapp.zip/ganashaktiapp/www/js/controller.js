// JavaScript Document
myApp.controller("controller", function($scope) {});
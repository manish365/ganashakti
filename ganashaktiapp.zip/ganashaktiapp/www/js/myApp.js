// JavaScript Document
var myApp = angular.module('myApp', []);